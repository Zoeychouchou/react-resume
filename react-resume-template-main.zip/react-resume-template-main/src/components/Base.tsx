import {FC, memo} from 'react';

const Base: FC = memo(() => {
  return <></>;
});

Base.displayName = 'Base';
export default Base;
